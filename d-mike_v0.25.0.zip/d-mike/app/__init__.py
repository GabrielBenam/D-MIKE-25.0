"""D-MIKE: paquete principal (este comentario evita que el cargador web de GitHub omita el archivo por estar vacío)."""
