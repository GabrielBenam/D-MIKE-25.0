"""Núcleo de D-MIKE: hoja, catálogo, proyecto, perfil y archivos."""
